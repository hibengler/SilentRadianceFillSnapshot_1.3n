/*
** wavinfo.c
** 04Aug2001.
**
** Copyright (C) 2001-2002 Steve Morphet <steve@morphet.org.uk>
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
**
** $Id: wavinfo.c,v 1.1 2004/04/05 21:24:42 sdm Exp $
** $Name: release_0_2_1_05Apr2004 $
*/

#include "wav.h"

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>

#define NUM_KNOWN_WAV_FMTS 4

int main( int argc, char **argv )
{
  char *filename;

  char *wav_formats[NUM_KNOWN_WAV_FMTS] = {
    "Unknown",
    "PCM Type 1",
    "Unknown",
    "PCM Type 3"
  };
  
  wav_t *wave_file;
  wav_err_t wave_err;

  float time_sec;
  int   time_min;
  
  int c;

  /* Check that we have one argument. */
  if( argc != 2 )
    {
      fprintf( stderr, "Usage: wavinfo filename\n" );
      exit( 1 );
    }
  
  /* Get the file name. */
  filename = argv[1];

  /* Open file for read. */
  wave_file = wav_open( filename, FALSE, FALSE, &wave_err );
  if( !wave_file )
    {
      fprintf( stderr, "Error %d opening %s: %s\n", 
	       wave_err,
	       filename,
	       wav_get_err_string( wave_err ) );
      exit( 2 );
    }

  /* Get header information from the file. */
  printf( "WAV header info:\n"
	  "\tFile length: %ld.\n"
	  "\tFormat: %s.\n"
	  "\t%d channels.\n"
	  "\t%d samples per second.\n"
	  "\t%d bits per sample.\n"
	  "\t%d byte block alignment.\n",
	  wave_file->file_length_m8 + 8,

	  ((wave_file->format_type >= NUM_KNOWN_WAV_FMTS) ?
	   "Unknown" : 
	   wav_formats[wave_file->format_type]),

	  wave_file->num_channels,
	  wave_file->sample_freq,
	  wave_file->bits_per_sample,
	  wave_file->block_align );

  /* Display chunk information. */
  printf( "WAV has %d chunks:\n", wave_file->num_chunks );
  for( c = 0; c < wave_file->num_chunks; ++c )
    {
      wav_chunk_t *chunk = &wave_file->chunk[c];

      printf( "\tChunk %d: \"%s\" at %ld.  "
	      "%ld bytes of data beginning at %ld.\n",
	      c,
	      chunk->name, (chunk->start - 8), 
	      chunk->size, chunk->start );
    }

  /* Calculate running time.  Assume all 'data' chunks are simple audio. */
  printf( "Length: %ld samples.\n", wave_file->num_samples );
  
  time_sec = ((float)wave_file->num_samples / 
	      (float)wave_file->sample_freq );
  printf( "Time: %.3f seconds.  ", time_sec );
  
  time_min = (int)time_sec / 60;
  time_sec -= (60.0f * time_min);
  printf( "(%d min %.3f sec).\n", time_min, time_sec );

  
  /* Close the wav file. */
  wav_close( wave_file );

  /* Done. */
  return 0;
}

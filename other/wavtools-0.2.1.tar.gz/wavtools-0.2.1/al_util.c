/* 
** al_util.c
** 06Jan2002.
**
** Copyright (C) 2002 Steve Morphet <steve@morphet.org.uk> 
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
**
** $Id: al_util.c,v 1.1 2004/04/05 21:24:41 sdm Exp $
** $Name: release_0_2_1_05Apr2004 $
*/

#include "al_util.h"


/*****************************************************************************
 * alutil_is_power_of_two()
 *
 * Test if a number is an integer power of two
 * 
 * Returns:  True or false.
 *
 * Input:    An integer number to test.
 * Output:   -
 *****************************************************************************/
bool alutil_is_power_of_two( unsigned int n )
{
  unsigned int minus1 = n - 1;
  return (n && ((n | minus1) == (n ^ minus1))) ? TRUE : FALSE;   
}


/*****************************************************************************
 * alutil_valid_num_channels()
 *
 * Test if a number a valid number of channels for a WAV file.
 * 
 * Returns:  True or false.
 *
 * Input:    An integer number of channels to test.
 * Output:   -
 *****************************************************************************/
bool alutil_valid_num_channels( int n )
{
  if( n <= 0 ) return FALSE;
  if( n > WAV_MAX_CHANNELS ) return FALSE;
  return TRUE;
}


/*****************************************************************************
 * alutil_valid_bits_per_sample()
 *
 * Test if a number is a valid number of bits per sample for a WAV file.
 * 
 * Returns:  True or false.
 *
 * Input:    An integer number of bits per sample to test.
 * Output:   -
 *****************************************************************************/
bool alutil_valid_bits_per_sample( int n )
{
  switch( n )
    {
    case 8:
    case 16:
    case 20:
    case 24:
    case 32:
      return TRUE;
    }
  return FALSE;
}


/*****************************************************************************
 * alutil_valid_wav_format()
 *
 * Test if a format is a type that we can handle.
 * 
 * Returns:  True or false.
 *
 * Input:    A wav_fmt_t code to test.
 * Output:   -
 *****************************************************************************/
bool alutil_valid_wav_format( wav_fmt_t n )
{
  switch( n )
    {
    case WAV_FMT_PCM_TYPE_1:
    case WAV_FMT_PCM_TYPE_3:
      return TRUE;
    default:
      return FALSE;
    }
}


/*****************************************************************************
 * alutil_bytes_per_sample()
 *
 * Return the sample size, rounded up to the nearest number of bytes.
 * 
 * Returns:  The sample size in bytes, or -1 if the number of bits per
 *           sample is not valid.
 *
 * Input:    An integer number of bits per sample.
 * Output:   -
 *****************************************************************************/
int alutil_bytes_per_sample( int b )
{
  switch( b )
    {
    case 8:
      return 1;
    case 16:
      return 2;
    case 20:
    case 24:
      return 3;
    case 32:
      return 4;
    }

  return -1;
}


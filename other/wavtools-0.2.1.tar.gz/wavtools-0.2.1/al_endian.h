/* 
** endian.h
** 04Aug2001.
**
** Copyright (C) 2001 Steve Morphet <steve@morphet.org.uk>
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
**
** $Id: al_endian.h,v 1.1 2004/04/05 21:24:41 sdm Exp $
** $Name: release_0_2_1_05Apr2004 $
*/

#if !defined ENDIAN_SENTRY
#define ENDIAN_SENTRY

/*****************************************************************************
 * endian_init()
 *
 * Test system endianness.
 *
 * Returns: Zero for success, non-zero for failure.
 * 
 *****************************************************************************/
int endian_init( void );


/*****************************************************************************
 * endian_convert_u32()
 *
 * Convert 32 bit unsigned little endian data to system endianness or vice
 * versa, if necessary.  On a little endian system the word will be unchanged.
 *
 * Input:   Little endian value     or     System endian value
 * Returns: System endian value     or     Little endian value
 *
 * Precondition: endian_init() has been called.
 *****************************************************************************/
unsigned long endian_convert_u32( unsigned long v );


/*****************************************************************************
 * endian_convert_u16()
 *
 * Convert 32 bit unsigned little endian data to system endianness or vice
 * versa, if necessary.  On a little endian system the word will be unchanged.
 *
 * Input:   Little endian value     or     System endian value
 * Returns: System endian value     or     Little endian value
 * 
 * Precondition: endian_init() has been called.
 *****************************************************************************/
unsigned short endian_convert_u16( unsigned short v );


#endif /* SENTRY */

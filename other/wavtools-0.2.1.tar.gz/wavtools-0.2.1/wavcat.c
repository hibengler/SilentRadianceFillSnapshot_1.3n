/*
** wavcat.c
** 07Sept2002.
**
** Copyright (C) 2002 Steve Morphet <steve@morphet.org.uk>
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
**
** $Id: wavcat.c,v 1.1 2004/04/05 21:24:41 sdm Exp $
** $Name: release_0_2_1_05Apr2004 $
*/

#include "wav.h"

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>

#define COPY_SIZE 0x4000 /* samples */
#define COPY_SHIFT 14 
#define COPY_MASK 0x3FFF

typedef struct
{
  char *filename;
  wav_t *wave;

} infile;

static int pick = 0;
static bool mix = FALSE;

static char *out_file = NULL;
static wav_t *out_wave = NULL;

static infile *input_file = NULL;
static int num_input_files = 0;

static short int *in_buffer[2];
static short int *out_buffer;

static void process_args( int argc, char **argv );
static void finish ( int exitcode );
static void print_usage( void );

int main( int argc, char **argv )
{
  int i;
  
  wav_err_t err;
  
  bool deinter;
  bool endian;
  int num_buff;
  unsigned long buff_size;

  int op_num_ch;

  in_buffer[0] = in_buffer[1] = out_buffer = NULL;

  /* Reset the random numbers. */
  srand( 0 );

  process_args( argc, argv );

  if( num_input_files < 1 )
    {
      print_usage();
      finish( 2 );
    }

  /* Check that all files are the same type (mono or stereo 16 bit PCM). */
  for( i = 0; i < num_input_files; ++i )
    {
      if( (input_file[i].wave->format_type != WAV_FMT_PCM_TYPE_1) ||
	  (input_file[i].wave->bits_per_sample != 16 ) ||
	  (input_file[i].wave->num_channels < 1) ||
	  (input_file[i].wave->num_channels > 2) )
	{
	  fprintf( stderr, "File %s is not mono or stereo 16 bit PCM.\n",
		   input_file[i].filename );
	  finish( 4 );
	}

      if( (mix || (pick != 0)) && input_file[i].wave->num_channels != 2 )
	{
	  fprintf( stderr, "Pick and mix can't be used with mono input.\n" );
	  finish( 4 );
	}
  
      /* Check all are the same type. (num channels and sample freq). */
      if( i > 0 )
	{
	  if( (input_file[i].wave->num_channels !=
	       input_file[i-1].wave->num_channels ) ||
	      (input_file[i].wave->sample_freq !=
	       input_file[i-1].wave->sample_freq ) )
	    {
	      int j;
	      fprintf( stderr,
		       "All files must have the same number of channels and "
		       "sampling frequency.\n" );
	      for( j = i - 1; j <= i; ++j )
		{
		  int nc = input_file[j].wave->num_channels;
		  fprintf( stderr, "%s has %d channel%s at %d Hz.\n",
			   input_file[j].filename,
			   nc, nc > 1 ? "s" : "", 
			   input_file[j].wave->sample_freq );
		}
	    }
	}
    }

  /* Create output file. */
  if( !out_file )
    {
      out_file = strdup( "output.wav" );
      if( !out_file )
	{
	      fprintf( stderr, "Error allocating output file name.\n" );
	      finish( 1 );	  
	}
    }
  
  /* Open the output file. */
  out_wave = wav_open( out_file, TRUE, FALSE, &err );
  if( !out_wave )
    {
      fprintf( stderr, "Error %d (%s) opening output file %s.\n", 
	       err, wav_get_err_string( err ), out_file );
      finish( 1 );
    }

  /* Number of output channels, and do we need to deinterlace the data? */
  if( mix || (pick != 0) ) 
    {
      op_num_ch = 1;
      deinter = TRUE;
      endian = mix ? TRUE : FALSE;
    }
  else
    {
      op_num_ch = input_file[0].wave->num_channels;
      deinter = FALSE;
      endian = FALSE;
    }

  /* Write output header. */
  if( (err = wav_write_header( out_wave, 
			       input_file[0].wave->format_type,
			       op_num_ch,
			       input_file[0].wave->sample_freq,
			       input_file[0].wave->bits_per_sample ) ) )
    {
      fprintf( stderr, "Error %d (%s) writing header to %s.\n", 
	       err, wav_get_err_string( err ),
	       out_file );
    }

  /* Work out buffer sizes from first wave. */
  wav_buffer_size( input_file[0].wave, COPY_SIZE, deinter, 
		   &num_buff, &buff_size) ;
  
  /* Allocate buffers. */
  for( i = 0; i < num_buff; ++i )
    {
      in_buffer[i] = malloc( buff_size );
      if( !in_buffer[i] )
	{
	  fprintf( stderr, "Failed to allocate input buffer %d.\n", i );
	  finish( 2 );
	}
    }
  if( mix )
    {
      /* We need an output buffer too. */
      out_buffer = malloc( buff_size );
      if( !out_buffer )
	{
	  fprintf( stderr, "Failed to allocate output buffer.\n" );
	  finish( 2 );
	}
    }

  /* Copy data from input to output. */
  for( i = 0; i < num_input_files; ++i )
    {
      unsigned long f_num = input_file[i].wave->num_samples;
      int num_blks = f_num >> COPY_SHIFT;
      int last_blk = f_num & COPY_MASK;
      int b;
      short int **write_src;

      if( mix )
	write_src = &out_buffer;
      else if( pick == 2 )
	write_src = &in_buffer[1];
      else
	write_src = in_buffer;

      printf( "File length: %ld.  %d blocks of %d, plus %d.\n", 
	      f_num, num_blks, COPY_SIZE, last_blk );

      if( last_blk ) num_blks += 1;
      for( b = 0; b < num_blks; ++b )
	{
	  unsigned long size = (b == num_blks - 1) ? last_blk : COPY_SIZE;
	  
	  /* Load data. */
	  wav_read( input_file[i].wave, b * COPY_SIZE, size, 
		    deinter, endian, (void**)in_buffer );

	  if( mix )
	    {
	      unsigned long s;
	      for( s = 0; s < size; ++s )
		{
		  /* Sum */
		  int sum = in_buffer[0][s] + in_buffer[1][s];

		  /* Crude dither. */
		  sum += (rand() & 0x01);

		  /* Divide. */
		  out_buffer[s] = sum / 2;
		}
	    }
       
	  /* Write output. */	    
	  wav_write( out_wave, size, deinter, endian, (void**)write_src );
	}
    }

  /* Done. */
  finish( 0 );
  return 0;
}


void process_args( int argc, char **argv )
{
  int a = 1;

  /* Options. */
  while( (a < argc) && *argv[a] == '-' )
    {
      /*printf( "Argument %s.\n", argv[a] );*/

      if( !strcmp( argv[a], "-pick" ) )
	{
	  /* Get channel number. 1 = left, 2 = right. */
	  a++;
	  if( a >= argc ) 
	    {
	      print_usage();
	      finish(3);
	    }

	  if( mix != 0 )
	    {
	      fprintf( stderr, "Can't pick and mix at the same time.\n" );
	      finish(3);
	    }

	  pick = atoi( argv[a] );

	  if( pick < 1 || pick > 2 ) 
	    {
	      print_usage();
	      finish(3);
	    }

	  printf( "Pick channel %d.\n", pick );
	}
      else if( !strcmp( argv[a], "-mix" ) )
	{
	  /* Set mix mode. */
	  if( pick )
	    {
	      fprintf( stderr, "Can't pick and mix at the same time.\n" );
	      finish(3);
	    }

	  mix = TRUE;

	  printf( "Mix channels.\n" );
	}
      else if( !strcmp( argv[a], "-o" ) )
	{
	  /* Outfile name. */
	  a++;
	  if( a >= argc ) 
	    {
	      print_usage();
	      finish(3);
	    }

	  out_file = strdup( argv[a] );
	  if( !out_file )
	    {
	      fprintf( stderr, "Error allocating output file name.\n" );
	      finish( 1 );
	    }

	  printf( "Output file %s.\n", out_file );
	}
      else
	{
	  print_usage();
	  finish( 2 );
	}

      a++;
    }

  /* Open input files. */
  /*printf( "Remaining args: a = %d.  argc = %d.\n", a, argc );*/
  while( a < argc )
    {
      wav_err_t wav_err;

      printf( "Filename %s.\n", argv[a] );

      num_input_files += 1;

      input_file = realloc( input_file, sizeof(infile) * num_input_files );

      if( !input_file )
	{
	  fprintf( stderr, "Error allocating input file array.\n" );
	  finish( 1 );
	}

      input_file[num_input_files - 1].wave = NULL;
      input_file[num_input_files-1].filename = strdup( argv[a] );
	  
      if( !input_file[num_input_files-1].filename )
	{
	  fprintf( stderr, "Error allocating input file name.\n" );
	  finish( 1 );	  
	}

      input_file[num_input_files-1].wave = 
	wav_open( input_file[num_input_files-1].filename, 
		  FALSE, FALSE, &wav_err );
	
      if( !input_file[num_input_files-1].wave )
	{
	  fprintf( stderr, "Error %d (%s) opening wave file %s.\n", 
		   wav_err, wav_get_err_string( wav_err ),
		   input_file[num_input_files-1].filename );
	  finish( 1 );
	}

      a++;
    }
}


void finish ( int exitcode )
{
  int infile;

  for( infile = 0; infile < num_input_files; ++infile )
    {
      if( input_file[infile].filename ) free( input_file[infile].filename );
      if( input_file[infile].wave ) wav_close( input_file[infile].wave );
    }

  if( out_file ) free( out_file );
  if( out_wave ) wav_close( out_wave );

  if( in_buffer[0] ) free( in_buffer[0] );
  if( in_buffer[1] ) free( in_buffer[1] );
  if( out_buffer )   free( out_buffer );

  exit( exitcode );
}


void print_usage( void )
{
  printf( "wavcat [options] file [file ...]\n" );

  printf( "Options:\n" );
  printf( "  -pick channel - Select channel 1 (left) or 2 (right) "
	  "for mono output.\n" );
  printf( "  -mix          - Mix two channels for mono output.\n" );
  printf( "  -o outfile    - Output file name (default output.wav).\n" );
}

/*
** endian.c
** 04Aug2001.
**
** Copyright (C) 2001 Steve Morphet <steve@morphet.org.uk>
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
**
** $Id: al_endian.c,v 1.1 2004/04/05 21:24:41 sdm Exp $
** $Name: release_0_2_1_05Apr2004 $
*/

#include "al_endian.h"

#include <stdio.h>
#include <assert.h>

/* *** Local functions. *** */

/* *** Global variables. *** */

/* Most systems are little endian.  Making the default value big-endian
   will help to catch programs that forget to call endian_init(). */
int big_endian = 1;
int endian_set = 0;

/*****************************************************************************
 * endian_init()
 *
 * Test system endianness.
 *
 * Returns: Zero for success, non-zero for failure.
 * 
 *****************************************************************************/
int endian_init( void )
{
  unsigned long data = 0x12345678;
  char *byte = (char*)&data;
  
  if( endian_set ) return 0;
  
  if( *byte == 0x78 )
    {
      /*printf( "Little endian.\n" );*/
      big_endian = 0;
      endian_set = 1;
      return 0;
    }
  else if( *byte == 0x12 )
    {
      /*printf( "Big endian.\n" );*/
      big_endian = 1;
      endian_set = 1;
      return 0;
    }
  else
    {
      /* Something strange happened. */
      return 1;
    }
}


/*****************************************************************************
 * endian_convert_u32()
 *
 * Convert 32 bit unsigned little endian data to system endianness or vice
 * versa, if necessary.  On a little endian system the word will be unchanged.
 *
 * Input:   Little endian value     or     System endian value
 * Returns: System endian value     or     Little endian value
 *
 * Precondition: endian_init() has been called.
 *****************************************************************************/
unsigned long endian_convert_u32( unsigned long v )
{
  assert( endian_set );

  if( big_endian )
    {
      unsigned long r;
      r = v & 0xFF;
      r <<= 8;
      v >>= 8;
      r |= v & 0xFF;
      r <<= 8;
      v >>= 8;
      r |= v & 0xFF;
      r <<= 8;
      v >>= 8;
      r |= v & 0xFF;
      return r;
    }
  else
    {
      return v;
    }
}



/*****************************************************************************
 * endian_convert_u16()
 *
 * Convert 32 bit unsigned little endian data to system endianness or vice
 * versa, if necessary.  On a little endian system the word will be unchanged.
 *
 * Input:   Little endian value     or     System endian value
 * Returns: System endian value     or     Little endian value
 * 
 * Precondition: endian_init() has been called.
 *****************************************************************************/
unsigned short endian_convert_u16( unsigned short v )
{
  assert( endian_set );

  if( big_endian )
    {
      unsigned short r;
      r = v & 0xFF;
      r <<= 8;
      v >>= 8;
      r |= v & 0xFF;
      return r;
    }
  else
    {
      return v;
    }
}



/*
** wavpad.c
** 04Aug2001.
**
** Copyright (C) 2001 Steve Morphet <steve@morphet.org.uk>
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
**
** $Id: wavpad.c,v 1.1 2004/04/05 21:24:42 sdm Exp $
** $Name: release_0_2_1_05Apr2004 $
*/

#include "wav.h"

/* We wouldn't normally include al_endian.h ourselves, but we're
   bypassing the audiolib functions and writing directly to the
   wave file, so we need to do our own endianness corrections. */
#include "al_endian.h"

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>

enum {
  BLOCK_SIZE = 2352
};

int main( int argc, char **argv )
{
  char *filename;
  
  wav_t *wave_file;
  wav_err_t wave_err;

  unsigned long total_bytes;

  long          last_chunk_start;
  unsigned long last_chunk_size;

  unsigned long padding_bytes;
  unsigned long new_file_size;
  unsigned long new_chunk_size;

  int last_c;
  int c;

  unsigned long cs_pos;
  unsigned long data_pos;
  unsigned long zero;
  unsigned long z;

  /* Check that we have one argument. */
  if( argc != 2 )
    {
      fprintf( stderr, "Usage: wavpad filename\n" );
      exit( 1 );
    }
  
  /* Get the file name. */
  filename = argv[1];

  /* Open file for read/write but do not create. */
  wave_file = wav_open( filename, FALSE, TRUE, &wave_err );
  if( !wave_file )
    {
      fprintf( stderr, "Error %d opening %s: %s\n", 
	       wave_err,
	       filename,
	       wav_get_err_string( wave_err ) );
      exit( 2 );
    }
  
  /* Check that the data is 16/44.1 stereo.  No point padding anything
     else. */
  if( (wave_file->num_channels != 2) ||
      (wave_file->sample_freq != 44100 ) || 
      (wave_file->bits_per_sample != 16) )
    {
      fprintf( stderr, "WAV file is not 16 bit, 44.1kHz, stereo.\n" );
      wav_close( wave_file );
      exit( 3 );
    }
  
  /* Assume all data chunks are audio, end to end, in order.  Padding
     will be added to the last chunk to bring the total to the appropriate
     number of samples.  An error occurs if the last chunk in the
     file is not a data chunk. */
  last_c = wave_file->num_chunks - 1;
  if( strcmp( wave_file->chunk[last_c].name, "data" ) )
    {
      /* Last chunk is not data. */
      fprintf( stderr, "Last chunk in file is not data.\n" );
      wav_close( wave_file );
      exit( 4 );
    }
  else
    {
      /* Last chunk is data - get details. */
      last_chunk_start = wave_file->chunk[last_c].start;
      last_chunk_size = wave_file->chunk[last_c].size;
    }
  
  /* Count total data size (bytes). */
  total_bytes = 0;
  for( c = 0; c <= last_c; ++c )
    {
      /* Look for the data chunk. */
      if( !strcmp( wave_file->chunk[c].name, "data" ) )
	{
	  total_bytes = wave_file->chunk[c].size;
	  break; 
	}
    }
  
  /* Calculate padding required. */
  if( total_bytes % BLOCK_SIZE )
    {
      padding_bytes = BLOCK_SIZE - (total_bytes % BLOCK_SIZE);
      assert( (padding_bytes % 4) == 0 );
      printf( "Adding %ld bytes padding... ", padding_bytes );
    }
  else
    {
      printf( "No padding required.\n" );
      exit(0);
    }

  /* Write the new file size to the WAV header.  Value stored is
     real size minus 8. Offset is 4 bytes into file. */
  new_file_size = wave_file->file_length_m8 + padding_bytes;
  new_file_size = endian_convert_u32( new_file_size );
  fseek( wave_file->fp, 4, SEEK_SET );
  fwrite( &new_file_size, sizeof(unsigned long), 1, wave_file->fp );

  /* Write the new chunk size to the chunk header. */
  new_chunk_size = wave_file->chunk[last_c].size + padding_bytes;
  new_chunk_size = endian_convert_u32( new_chunk_size );
  cs_pos = wave_file->chunk[last_c].start - 4;
  fseek( wave_file->fp, cs_pos, SEEK_SET );
  fwrite( &new_chunk_size, sizeof(unsigned long), 1, wave_file->fp );
  
  /* Write zeroes to the end of the last chunk. */
  zero = 0UL; /* No endianness correction required. */
  data_pos = (wave_file->chunk[last_c].start + 
	      wave_file->chunk[last_c].size);
  fseek( wave_file->fp, data_pos, SEEK_SET );
  for( z = 0; z < padding_bytes; z += 4 )
    {
      fwrite( &zero, sizeof(unsigned long), 1, wave_file->fp );
    }

  printf("OK.\n");

  /* Close the wav file. */
  wav_close( wave_file );

  /* Done. */
  return 0;
}

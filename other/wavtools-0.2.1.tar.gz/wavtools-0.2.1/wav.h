/* 
** wav.h
** 04Aug2001.
**
** Copyright (C) 2001-2002 Steve Morphet <steve@morphet.org.uk>
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
**
** $Id: wav.h,v 1.1 2004/04/05 21:24:41 sdm Exp $
** $Name: release_0_2_1_05Apr2004 $
*/

#if !defined WAV_SENTRY
#define WAV_SENTRY


#include "al_util.h"

#include <stdio.h>


/* Error codes for the wav_get_hdr() function. */
#define X(c,s) c
typedef enum {
#include "wav_err.x"
  WAV_ERR_NUM_CODES
} wav_err_t;
#undef X


/* Structure describing a WAV chunk. */
typedef struct
{
  char *name;

  unsigned long size;          /* Size in bytes. */
  long start;                  /* Start position in file. */
  
  int is_data;                 /* True if chunk is data. */

} wav_chunk_t;


/* Structure describing the format of a WAV file. */
typedef struct
{
  FILE *fp;

  unsigned long file_length_m8;

  bool mode_write;
  bool write_hdr_set;

  /* Format info. */
  wav_fmt_t format_type;
  int num_channels;
  int sample_freq;
  int bits_per_sample;
  int bytes_per_sample;
  int block_align;

  /* Data info. */
  long data_start;
  unsigned long num_samples;

  /* Chunk data. */
  int num_chunks;
  wav_chunk_t *chunk;

} wav_t;


/*****************************************************************************
 * wav_get_err_string() 
 *
 * Get a string corresponding to a wav_hdr_err_t code.
 *
 * Input:   ecode - The error code.
 * Returns: a pointer to a null terminated string describing the error,
 *          or NULL for failure.
 *****************************************************************************/
char *wav_get_err_string( wav_err_t ecode );


/*****************************************************************************
 * wav_open()
 *
 * Get the header data of a WAV file.
 * 
 * Returns:  A pointer to a wav_t structure for the wave, or NULL for failure.
 * Input:    File name.
 *           write - TRUE to open for write, FALSE for read.
 *           read_write - Adds '+' to fopen mode.
 * Output:   err - Error code (zero for success).
 *
 *****************************************************************************/
wav_t* wav_open( char *filename, bool write, bool read_write, wav_err_t *err );


/*****************************************************************************
 * wav_close()
 *
 * Get the header data of a WAV file.
 * 
 * Returns:  A pointer to a wav_t structure for the wave, or NULL for failure.
 * Input:    File name.
 * Output:   -
 *****************************************************************************/
void wav_close( wav_t *w );


/*****************************************************************************
 * wav_buffer_size()
 *
 * Work out the buffer sizes that will be required for a call to wav_read().
 * Interlaced data goes into a single buffer, deinterlaced data uses one
 * buffer per channel.
 * 
 * Returns:  An error code.
 * Input:    w     - Wave structure.
 *           len   - Number of samples to read.
 *           deinter - TRUE to deinterlace samples.
 * Output:   num_buff  - Number of buffers required.
 *           buff_size - Required size of _each_ buffer in bytes.
 *****************************************************************************/
wav_err_t wav_buffer_size( wav_t *w, 
			   unsigned long len,
			   bool deinter,
			   int *num_buff,
			   unsigned long *buff_size );


/*****************************************************************************
 * wav_read()
 *
 * Read data from a WAV file.  Establish buffer sizes with a call
 * to wav_buffer_size().  List buffer start addresses as var args.
 * Leave addresses NULL to discard data.
 * 
 * Deinterlaced data creates one buffer per channel.  Interlaced data
 * creates a single buffer with interlaced samples, e.g. LRLRLR.
 *
 * Endian conversion converts file data (little endian) to system
 * endianness.
 * 
 * Returns:  An error code.
 * Input:    w     - Wave structure.
 *           start - Start sample number.
 *           len   - Number of samples to read.
 *           deinter - TRUE to deinterlace samples.
 *           endian  - TRUE to do endian conversion on data.
 *           dest    - Array of destination buffer pointers.  Length of
 *                     array determined by wav_buffer_size().
 * Output:   
 *****************************************************************************/
wav_err_t wav_read( wav_t *w, unsigned long start, unsigned long len,
		    bool deinter, bool endian, void **dest );


/*****************************************************************************
 * wav_write_header()
 *
 * Write header data to a WAV file.  The file should have been opened
 * for write using wav_open().
 *
 * Returns:  An error code.
 * Input:    w      - Wave structure.
 *           format - A WAV_FMT_*** code.
 *           num_channels - Number of channels.
 *           sample_freq  - Sampling frequency in samples per second.
 *           bits_per_sample - Number of bits per sample.
 * Output:   
 *****************************************************************************/
wav_err_t wav_write_header( wav_t *w, wav_fmt_t format, int num_channels,
			    int sample_freq, int bits_per_sample );


/*****************************************************************************
 * wav_write()
 *
 * Write data to a WAV file.  The data is appended to the end of the
 * file.  Data may be interleaved or not.  Endian conversion may be
 * applied.  wav_write() may be called more than once to append data
 * to the file.
 *
 * Returns:  An error code.
 * Input:    w      - Wave structure.
 *           num_samples  - Number of samples to write.
 *           deinter      - TRUE if data is not interlaced, FALSE if it is.
 *           endian       - TRUE if endian conversion should be applied.
 *           src          - Array of destination buffer pointers.  Length of
 *                          array determined by wav_buffer_size().
 * Output:   
 *
 * On entry: wav_write_header() has been called once.
 *****************************************************************************/
wav_err_t wav_write( wav_t *w, unsigned long len,
		     bool deinter, bool endian, void **src );


#endif /* SENTRY */

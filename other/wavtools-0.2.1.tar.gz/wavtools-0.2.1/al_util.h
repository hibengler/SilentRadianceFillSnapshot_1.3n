/* 
** al_util.h
** 05Jan2002.
**
** Copyright (C) 2002 Steve Morphet <steve@morphet.org.uk> 
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
**
** $Id: al_util.h,v 1.1 2004/04/05 21:24:41 sdm Exp $
** $Name: release_0_2_1_05Apr2004 $
*/

#if !defined AL_UTIL_SENTRY
#define AL_UTIL_SENTRY

typedef int bool;
enum {
  FALSE = 0,
  TRUE = 1
};

/* 32 bit floating point representation of audio data. 
   Internal format is 32768.0 == 0dBFS. */
typedef float sample;
#define FULL_SCALE 32768.0

/* Constants for file formats.  
   ##### Check the full scale values.
*/

#define OFFSET_8 128.0
#define FSCALE_8 127.0
#define FSCALE_16  32767.0
#define FSCALE_32A 8388608.0
#define FSCALE_32B 32768.0
#define FSCALE_32C 1.0
#define FSCALE_32D 8388607.0 
#define FSCALE_32E 524287.0 
#define FSCALE_32F 2147483647.0 

/* WAV format codes for the wav_header_t structure. */
typedef enum {
  WAV_FMT_NONE = 0,
  WAV_FMT_PCM_TYPE_1 = 1,  /* Integer PCM. */
  WAV_FMT_PCM_TYPE_3 = 3   /* Floating point PCM. */
} wav_fmt_t;

enum {
  WAV_MAX_CHANNELS = 2
};

/*****************************************************************************
 * alutil_is_power_of_two()
 *
 * Test if a number is an integer power of two
 * 
 * Returns:  True or false.
 *
 * Input:    An integer number to test.
 * Output:   -
 *****************************************************************************/
bool alutil_is_power_of_two( unsigned int n );


/*****************************************************************************
 * alutil_valid_num_channels()
 *
 * Test if a number a valid number of channels for a WAV file.
 * 
 * Returns:  True or false.
 *
 * Input:    An integer number of channels to test.
 * Output:   -
 *****************************************************************************/
bool alutil_valid_num_channels( int n );


/*****************************************************************************
 * alutil_valid_bits_per_sample()
 *
 * Test if a number is a valid number of bits per sample for a WAV file.
 * 
 * Returns:  True or false.
 *
 * Input:    An integer number of bits per sample to test.
 * Output:   -
 *****************************************************************************/
bool alutil_valid_bits_per_sample( int n );


/*****************************************************************************
 * alutil_valid_wav_format()
 *
 * Test if a format is a type that we can handle.
 * 
 * Returns:  True or false.
 *
 * Input:    A wav_fmt_t code to test.
 * Output:   -
 *****************************************************************************/
bool alutil_valid_wav_format( wav_fmt_t n );


/*****************************************************************************
 * alutil_bytes_per_sample()
 *
 * Return the sample size, rounded up to the nearest number of bytes.
 * 
 * Returns:  The sample size in bytes.
 *
 * Input:    An integer number of bits per sample.
 * Output:   -
 *****************************************************************************/
int alutil_bytes_per_sample( int b );


#endif /* AL_UTIL_SENTRY */

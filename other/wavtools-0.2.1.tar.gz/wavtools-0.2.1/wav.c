/*
** wav.c
** 04Aug2001.
**
** Copyright (C) 2001-2002 Steve Morphet <steve@morphet.org.uk>
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
**
** $Id: wav.c,v 1.1 2004/04/05 21:24:41 sdm Exp $
** $Name: release_0_2_1_05Apr2004 $
*/

#include "wav.h"
#include "al_endian.h"

#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdarg.h>

/* *** Local functions. *** */

static void wav_dealloc_wav_t_contents( wav_t *w );
static wav_err_t wav_scan_chunks( wav_t* w, wav_err_t *err );
static wav_err_t wav_read_fmt( wav_t* w, wav_err_t *err );

static void wav_read_8  ( FILE *fp, int num_ch, unsigned long num_s, 
			  bool deinter, unsigned char **dest );
static void wav_read_16 ( FILE *fp, int num_ch, unsigned long num_s, 
			  bool deinter, bool endian, short int **dest );
static void wav_read_32 ( FILE *fp, int num_ch, unsigned long num_s, 
			  bool deinter, bool endian, unsigned long **dest );

static void wav_write_8 ( FILE *fp, int num_ch, unsigned long num_s, 
			  bool deinter, unsigned char **src );
static void wav_write_16( FILE *fp, int num_ch, unsigned long num_s, 
			  bool deinter, bool endian, short int **src );
static void wav_write_32( FILE *fp, int num_ch, unsigned long num_s, 
			  bool deinter, bool endian, unsigned long **src );



/*****************************************************************************
 * wav_open()
 *
 * Get the header data of a WAV file.
 * 
 * Returns:  A pointer to a wav_t structure for the wave, or NULL for failure.
 * Input:    File name.
 *           write - TRUE to open for write, FALSE for read.
 *           read_write - Adds '+' to fopen mode.
 * Output:   err - Error code (zero for success).
 *
 *****************************************************************************/
wav_t* wav_open( char *filename, bool write, bool read_write, wav_err_t *err )
{
  wav_t *w;

  /* Call endian init.  Doing this every time we open a wav is 
     unnecessary, but it ensures that it is always done before a
     wav is read. */
  if( endian_init() )
    {
      if( err ) *err = WAV_ERR_ENDIAN;
      return NULL;
    }

  /* Allocate wave info structure. */
  w = malloc( sizeof( wav_t ) );

  if( w )
    {
      /* Construct wav object. */
      
      /* Open the file. */
      w->fp = fopen( filename, (write ? 
				(read_write ? "wb+" : "wb") : 
				(read_write ? "rb+" : "rb") ) );
      if( !w->fp )
	{
	  /* Failed to open file. */
	  if( err ) *err = WAV_ERR_OPEN;
	  free( w );
	  return NULL;
	}

      /* Fill in pointers in wav_t. */
      w->chunk = NULL;

      if( write )
	{
	  /* Init write data members. */
	  w->mode_write = TRUE;
	  w->write_hdr_set = FALSE;
	}
      else
	{
	  /* Init write data members. */
	  w->mode_write = FALSE;
	  w->write_hdr_set = FALSE;

	  /* Read header info. */
	  rewind( w->fp );
	  if( wav_scan_chunks( w, err ) )
	    {
	      /* Error reading header - error code will be stored, but
		 w contents will not be allocated. */
	      fclose( w->fp );
	      free( w );
	      return NULL;
	    }
	}
    }
  
  return w;
}


/*****************************************************************************
 * wav_close()
 *
 * Get the header data of a WAV file.
 * 
 * Returns:  A pointer to a wav_t structure for the wave, or NULL for failure.
 * Input:    File name.
 * Output:   -
 *****************************************************************************/
void wav_close( wav_t *w )
{
  if( w->mode_write && w->write_hdr_set )
    {
      unsigned long data32;

      /* Update file header with amount of data written.  This use
         of block align only valid for PCM. */

      /* File length minus 8. */
      data32 = w->data_start + (w->num_samples * w->block_align) - 8;
      data32 = endian_convert_u32( data32 );
      fseek( w->fp, 0x04, SEEK_SET );
      fwrite( &data32, sizeof( unsigned long ), 1, w->fp );
      
      /* Data chunk size. */
      data32 = w->num_samples * w->block_align;
      data32 = endian_convert_u32( data32 );
      fseek( w->fp, w->data_start - sizeof(unsigned long), SEEK_SET );
      fwrite( &data32, sizeof( unsigned long ), 1, w->fp );
    }

  wav_dealloc_wav_t_contents( w );
  fclose( w->fp );
  free( w );
}


/*****************************************************************************
 * wav_get_err_string() 
 *
 * Get a string corresponding to a wav_hdr_err_t code.
 *
 * Input:   ecode - The error code.
 * Returns: a pointer to a null terminated string describing the error,
 *          or NULL for failure.
 *****************************************************************************/
char *wav_get_err_string( wav_err_t ecode )
{
#define X(c,s) s
  static char *wav_err_string[] = {
#include "wav_err.x"
  };
#undef X
  char *rval = NULL;

  if( ecode < WAV_ERR_NUM_CODES )
    {
      rval = wav_err_string[ecode];
    }
  return rval;
}


/*****************************************************************************
 * wav_scan_chunks() 
 *
 * Check the header of a WAV file, and read the chunk information.
 * When the 'fmt' chunk is found, call a function to read the format
 * information.
 * Called by wav_open().
 *
 * Input:   w - Wave info structure.
 * Output:  err - Error code.
 * Returns: The error code (zero for success).
 *
 * On entry: File pointer (w->fp) is at start of file.
 * On exit:  Members of w filled in with format information
 *           from WAV file, unless error occurs.
 *****************************************************************************/
wav_err_t wav_scan_chunks( wav_t* w, wav_err_t *err )
{
  char fourcc[4+1];
  wav_err_t ecode = WAV_OK;

  bool got_fmt = FALSE;
  bool got_data = FALSE;

  unsigned long data32;
  fourcc[4] = '\0';

  /* Look for the 'RIFF' string. */
  fread( fourcc, sizeof(char), 4, w->fp );
  if( strcmp( fourcc, "RIFF" ) )
    {
      /* Couldn't find the RIFF code. */
      ecode = WAV_ERR_NOT_WAV;
      goto wav_scan_err_return;
    }

  /* Get file length (value returned is file length - 8). */
  fread( &data32, sizeof(unsigned long), 1, w->fp );
  w->file_length_m8 = endian_convert_u32( data32 );

  /* Look for the 'WAVE' string. */
  fread( fourcc, sizeof(char), 4, w->fp );
  if( strcmp( fourcc, "WAVE" ) )
    {
      /* Couldn't find the WAVE code. */
      ecode = WAV_ERR_NOT_WAV;
      goto wav_scan_err_return;
    }

  /* Scan all chunks. File pointer is already at first chunk start. */
  w->num_chunks = 0;
  w->chunk = NULL;

  while( ftell(w->fp) < (long)(w->file_length_m8 + 8) )
    {
      unsigned long data_len;
      char *t_name;

      /* Get the next chunk name. */
      fread( fourcc, sizeof(char), 4, w->fp );
      
      /* Get the size. */
      fread( &data32, sizeof(unsigned long), 1, w->fp );
      data_len = endian_convert_u32( data32 );

      /* Reallocate the arrays. */
      w->num_chunks += 1;
      
      w->chunk = realloc( w->chunk, sizeof(wav_chunk_t) * w->num_chunks );
      if( !w->chunk )
	{
	  ecode = WAV_ERR_ALLOC;
	  goto wav_scan_err_return;
	}

      /* Set up chunk info. */
      t_name = strdup( fourcc );
      if( !t_name )
	{
	  ecode = WAV_ERR_ALLOC;
	  goto wav_scan_err_return;
	}
      w->chunk[w->num_chunks-1].name = t_name;
      w->chunk[w->num_chunks-1].size = data_len;
      
      w->chunk[w->num_chunks-1].start = ftell( w->fp );

      /* Clear members that are only relevant to data chunks. */
      w->chunk[w->num_chunks-1].is_data = 0;

      if( !strcmp( fourcc, "fmt " ) )
	{
	  /* Check fmt data size is OK. */
	  if( data_len != 0x10 )
	    {
	      ecode = WAV_ERR_INCONSISTENT;
	      goto wav_scan_err_return;
	    }

	  got_fmt = TRUE;
	  if( wav_read_fmt( w, &ecode ) )
	    {
	      /* Error reading format - error code is set. */
	      goto wav_scan_err_return;
	    }

	  /* After fmt read, we're in the correct position to read the
             next chunk. */
	}
      else 
	{
	  /* Not a format chunk.  Could be data. */
	  if( !strcmp( fourcc, "data" ) )
	    {
	      if( got_data )
		{
		  /* This is a second data chunk.  Not allowed. */
		  ecode = WAV_ERR_DATA_CHUNK;
		  goto wav_scan_err_return;
		}
	      
	      /* Store start position of data. */
	      w->data_start = w->chunk[w->num_chunks-1].start;

	      /* Count the samples in this chunk. */
	      w->num_samples = data_len / (w->bytes_per_sample *
					   w->num_channels );
	      
	      /* Mark this as a data chunk (we don't want to have to
		 strcmp every time to test it). */
	      w->chunk[w->num_chunks-1].is_data = 1;

	      got_data = TRUE;
	    }

	  /* Move forwards to the next chunk. */
	  fseek( w->fp, data_len, SEEK_CUR );
	}
    }

  /* Check that a format chunk was found. */
  if( !got_fmt )
    {
      ecode = WAV_ERR_NOT_WAV;
      goto wav_scan_err_return;
    }
  
  /* Everything seems to be OK. */
  goto wav_scan_ok_return;

 wav_scan_err_return:
  /* Error cleanup. */
  wav_dealloc_wav_t_contents( w );

 wav_scan_ok_return:
  if( err ) *err = ecode;
  return ecode;
}


/*****************************************************************************
 * wav_read_fmt() 
 *
 * Read the format information from the 'fmt' chunk of a WAV file.
 * Called by wav_scan_chunks().
 *
 * Input:   w - Wave info structure.
 * Output:  err - Error code.
 * Returns: The error code (zero for success).
 *
 * On entry: File pointer (w->fp) is at start of fmt chunk data.
 * On exit:  Format members of w filled in with format information
 *           from WAV file, unless error occurs.
 *****************************************************************************/
wav_err_t wav_read_fmt( wav_t* w, wav_err_t *err )
{
  unsigned long bytes_per_sec;

  unsigned long data32;
  unsigned short data16;

  wav_err_t ecode = WAV_OK;

  /* On entry, file pointer is at start of data part of format
     chunk. */

  /* Get format. */
  fread( &data16, sizeof(unsigned short), 1, w->fp );
  w->format_type = endian_convert_u16( data16 );
  if( !alutil_valid_wav_format( w->format_type ) )
    {
      ecode = WAV_ERR_UNSUPPORTED_FORMAT;
      goto wav_fmt_err_return;
    }
  
  /* Get number of channels. */
  fread( &data16, sizeof(unsigned short), 1, w->fp );
  w->num_channels = endian_convert_u16( data16 );
  if( !alutil_valid_num_channels( w->num_channels ) )
    {
      /* Not a supported number of channels. */
      ecode = WAV_ERR_CHANNEL_COUNT;
      goto wav_fmt_err_return;      
    }

  /* Get sample rate. */
  fread( &data32, sizeof(unsigned long), 1, w->fp );
  w->sample_freq = endian_convert_u32( data32 );

  /* Get sample rate and block alignment. */
  fread( &data32, sizeof(unsigned long), 1, w->fp );
  bytes_per_sec = endian_convert_u32( data32 );

  fread( &data16, sizeof(unsigned short), 1, w->fp );
  w->block_align = endian_convert_u16( data16 );

  /* Get sample size. */
  fread( &data16, sizeof(unsigned short), 1, w->fp );
  w->bits_per_sample = endian_convert_u16( data16 );
  if( !alutil_valid_bits_per_sample( w->bits_per_sample ) )
    {
      ecode = WAV_ERR_WORD_LENGTH;
      goto wav_fmt_err_return;
    }
  w->bytes_per_sample = alutil_bytes_per_sample( w->bits_per_sample );

  /* Check consistency.  Block align may be greater than or equal
     to number of bytes, but never less than. */
  if( w->block_align < (w->num_channels * w->bytes_per_sample) )
    {
      ecode = WAV_ERR_INCONSISTENT;
      goto wav_fmt_err_return;
    }
  
  if( bytes_per_sec != 
      (unsigned long)(w->block_align * w->sample_freq) )
    {
      ecode = WAV_ERR_INCONSISTENT;
      goto wav_fmt_err_return;
    }

  /* OK. */
  goto wav_fmt_ok_return;

 wav_fmt_err_return:
  /* Error cleanup. */
  wav_dealloc_wav_t_contents( w );

 wav_fmt_ok_return:
  if( err ) *err = ecode;
  return ecode;
}


/*****************************************************************************
 * wav_deallocate_wav_t_contents() 
 *
 * Deallocate dynamically allocated members of a wav_t.
 * Reset num_chunks and format members to zero.
 *
 * Input:   w - Wave info structure.
 * Returns: void.
 *
 *****************************************************************************/
void wav_dealloc_wav_t_contents( wav_t *w )
{
  int c;

  /* Free chunk info. */
  if( w->num_chunks )
    {
      for( c = 0; c < w->num_chunks; ++c )
	{
	  /* Free names. */
	  if( w->chunk[c].name ) free( w->chunk[c].name );
	}
      /* Free chunk array. */
      free( w->chunk );
    }
  w->num_chunks = 0;
  w->chunk = NULL;

  /* Clear format data members in case user tries to use the structure
     after error return. */
  w->format_type = WAV_FMT_NONE;
  w->num_channels = 0;
  w->sample_freq = 0;
  w->bits_per_sample = 0;
  w->block_align = 0;
  
  w->data_start = 0;
  w->num_samples = 0;

  w->mode_write = FALSE;
  w->write_hdr_set = FALSE;

  /* Don't touch file pointer - it may not be closed yet. */
}


/*****************************************************************************
 * wav_buffer_size()
 *
 * Work out the buffer sizes that will be required for a call to wav_read().
 * Interlaced data goes into a single buffer, deinterlaced data uses one
 * buffer per channel.
 * 
 * Returns:  An error code.
 * Input:    w     - Wave structure.
 *           len   - Number of samples to read.
 *           deinter - TRUE to deinterlace samples.
 * Output:   num_buff  - Number of buffers required.
 *           buff_size - Required size of _each_ buffer in bytes.
 *****************************************************************************/
wav_err_t wav_buffer_size( wav_t *w, unsigned long len,
			   bool deinter,
			   int *num_buff,
			   unsigned long *buff_size )
{
  wav_err_t err = WAV_OK;

  if( w->mode_write )
    {
      /* File not open for read. */
      return WAV_ERR_OPEN;
    }
  
  if( num_buff )
    {
      /* One buffer for interlaced data, else, number of channels. */
      *num_buff = deinter ? w->num_channels : 1;
    }
  
  if( buff_size )
    {
      unsigned long ch_data_size;
      
      ch_data_size = w->bytes_per_sample * len;

      if( !deinter )
	ch_data_size *= w->num_channels;

      *buff_size = ch_data_size;
    }

  return err;
}


/*****************************************************************************
 * wav_read_8()
 *
 * Read 8 bit data to buffers, with or without deinterlacing.
 * 
 *****************************************************************************/
void wav_read_8( FILE *fp, int num_ch, unsigned long num_s, 
		 bool deinter, unsigned char **dest )
{
  unsigned long s;
  int ch;

  unsigned char *ldest[WAV_MAX_CHANNELS];

  /* Copy pointers. */
  for( ch = 0; ch < num_ch; ++ch ) ldest[ch] = dest[ch];

  if( deinter && (num_ch > 1) )
    {
      /* Read each channel individually.  No endian convert
	 required for 8 bit data. */
      for( s = 0; s < num_s; ++s )
	for( ch = 0; ch < num_ch; ++ch )
	  {
	    if( ldest[ch] )
	      {
		fread( ldest[ch], sizeof(unsigned char), 1, fp );
		ldest[ch]++;
	      }
	  }
    }
  else
    {
      /* Read everything in one read.  No endian convert
	 required. */
      if( ldest[0] )
	{
	  fread( ldest[0], sizeof(unsigned char), num_s, fp );
	}
    }
}


/*****************************************************************************
 * wav_read_16()
 *
 * Read 16 bit data to buffers, with or without deinterlacing and endian
 * conversion.
 * 
 *****************************************************************************/
void wav_read_16( FILE *fp, int num_ch, unsigned long num_s, 
		  bool deinter, bool endian, short int **dest )
{
  unsigned long s;
  int ch;

  short int *ldest[WAV_MAX_CHANNELS];

  /* Copy pointers. */
  for( ch = 0; ch < num_ch; ++ch ) ldest[ch] = dest[ch];

  if( deinter && (num_ch > 1) )
    {
      /* Read each channel individually. */
      if( endian )
	{
	  /* With endian conversion. */
	  for( s = 0; s < num_s; ++s )
	    for( ch = 0; ch < num_ch; ++ch )
	      {
		if( ldest[ch] )
		  {
		    fread( ldest[ch], sizeof(short int), 1, fp );
		    *ldest[ch] = endian_convert_u16( *ldest[ch] );
		    ldest[ch]++;
		  }
	      }
	}
      else
	{
	  /* Without endian conversion. */
	  for( s = 0; s < num_s; ++s )
	    for( ch = 0; ch < num_ch; ++ch )
	      {
		if( ldest[ch] )
		  {
		    fread( ldest[ch], sizeof(short int), 1, fp );
		    ldest[ch]++;
		  }
	      }
	}
    }
  else
    {
      /* Read everything in one read. */
      if( ldest[0] )
	{
	  fread( ldest[0], sizeof(short int), num_s, fp );
	}

      if( endian )
	{
	  for( s = 0; s < num_s; ++s )
	    {
	      *ldest[0] = endian_convert_u16( *ldest[0] );
	      ldest[0]++;
	    }
	}
    }
}


/*****************************************************************************
 * wav_read_32()
 *
 * Read 32 bit data to buffers, with or without deinterlacing and endian
 * conversion.
 * 
 *****************************************************************************/
void wav_read_32( FILE *fp, int num_ch, unsigned long num_s, 
		  bool deinter, bool endian, unsigned long **dest )
{
  unsigned long s;
  int ch;

  unsigned long *ldest[WAV_MAX_CHANNELS];

  /* Copy pointers. */
  for( ch = 0; ch < num_ch; ++ch ) ldest[ch] = dest[ch];

  if( deinter && (num_ch > 1) )
    {
      /* Read each channel individually. */
      if( endian )
	{
	  /* With endian conversion. */
	  for( s = 0; s < num_s; ++s )
	    for( ch = 0; ch < num_ch; ++ch )
	      {
		if( ldest[ch] )
		  {
		    fread( ldest[ch], sizeof(unsigned long), 1, fp );
		    *ldest[ch] = endian_convert_u32( *ldest[ch] );
		    ldest[ch]++;
		  }
	      }
	}
      else
	{
	  /* Without endian conversion. */
	  for( s = 0; s < num_s; ++s )
	    for( ch = 0; ch < num_ch; ++ch )
	      {
		if( ldest[ch] )
		  {
		    fread( ldest[ch], sizeof(unsigned long), 1, fp );
		    ldest[ch]++;
		  }
	      }
	}
    }
  else
    {
      /* Read everything in one read. */
      if( ldest[0] )
	{
	  fread( ldest[0], sizeof(unsigned long), num_s, fp );
	}
      if( endian )
	{
	  for( s = 0; s < num_s; ++s )
	    {
	      *ldest[0] = endian_convert_u32( *ldest[0] );
	      ldest[0]++;
	    }
	}
    }
}


/*****************************************************************************
 * wav_read()
 *
 * Read data from a WAV file.  Establish buffer sizes with a call
 * to wav_buffer_size().  List buffer start addresses as var args.
 * Leave addresses NULL to discard data.
 * 
 * Deinterlaced data creates one buffer per channel.  Interlaced data
 * creates a single buffer with interlaced samples, e.g. LRLRLR.
 *
 * Endian conversion converts file data (little endian) to system
 * endianness.
 * 
 * Returns:  An error code.
 * Input:    w     - Wave structure.
 *           start - Start sample number.
 *           len   - Number of samples to read.
 *           deinter - TRUE to deinterlace samples.
 *           endian  - TRUE to do endian conversion on data.
 *           dest    - Array of destination buffer pointers.  Length of
 *                     array determined by wav_buffer_size().
 * Output:   
 *****************************************************************************/
wav_err_t wav_read( wav_t *w, unsigned long start, unsigned long len,
		    bool deinter, bool endian, void **dest )
{
  int num_ch;
  unsigned long num_s;

  wav_err_t err = WAV_OK;

  /* Check mode. */
  if( w->mode_write )
    {
      /* File not open for read. */
      return WAV_ERR_OPEN;
    }

  /* Check range. */
  if( (start >= w->num_samples) ||
      ((start + len) > w->num_samples) )
    {
      err = WAV_ERR_RANGE;
      return err;
    }

  /* Number of channels and samples per buffer. */
  num_ch = deinter ? w->num_channels : 1;
  num_s = len * (deinter ? 1 : w->num_channels);

  /* Seek to start of data.  This use of block align only valid for PCM. */
  fseek( w->fp, 
	 w->data_start + (w->block_align * start ), 
	 SEEK_SET );

  switch( w->bits_per_sample )
    {
    case 8:
      {
	wav_read_8( w->fp, num_ch, num_s, deinter, 
		    (unsigned char **)dest );
	break;
      }
    case 16:
      {
	wav_read_16( w->fp, num_ch, num_s, deinter, endian, 
		     (short int **)dest );
	break;
      }
    case 32:
      {
	wav_read_32( w->fp, num_ch, num_s, deinter, endian, 
		     (unsigned long **)dest );
	break;
      }
    default:
      {
	err = WAV_ERR_WORD_LENGTH;
      }
    }

  return err;
}


/*****************************************************************************
 * wav_write_header()
 *
 * Write header data to a WAV file.  The file should have been opened
 * for write using wav_open().
 *
 * Returns:  An error code.
 * Input:    w      - Wave structure.
 *           format - A WAV_FMT_*** code.
 *           num_channels - Number of channels.
 *           sample_freq  - Sampling frequency in samples per second.
 *           bits_per_sample - Number of bits per sample.
 * Output:   
 *****************************************************************************/
wav_err_t wav_write_header( wav_t *w, wav_fmt_t format, int num_channels,
			    int sample_freq, int bits_per_sample )
{
  unsigned long data32;
  unsigned short data16;

  /* Check mode. */
  if( !w->mode_write )
    return WAV_ERR_OPEN;

  /* Check format. */
  if( !alutil_valid_wav_format( format ) )
    return WAV_ERR_UNSUPPORTED_FORMAT;
  if( !alutil_valid_num_channels( num_channels ) )
    return WAV_ERR_CHANNEL_COUNT;
  if( !alutil_valid_bits_per_sample( bits_per_sample ) )
    return WAV_ERR_WORD_LENGTH;

  /* Set up structure. */
  w->file_length_m8 = 0;
  w->format_type = format;
  w->num_channels = num_channels;
  w->sample_freq = sample_freq;
  w->bits_per_sample = bits_per_sample;
  w->bytes_per_sample = alutil_bytes_per_sample( bits_per_sample );

  /* True for PCM only. */
  w->block_align = num_channels * w->bytes_per_sample;
  
  /* Write header to file. */
  rewind( w->fp );

  /* RIFF header. */
  fwrite( "RIFF", sizeof(char), 4, w->fp );
  
  data32 = endian_convert_u32( w->file_length_m8 );
  fwrite( &data32, sizeof(unsigned long), 1, w->fp );

  fwrite( "WAVE", sizeof(char), 4, w->fp );
  
  /* Write format chunk. */
  fwrite( "fmt ", sizeof(char), 4, w->fp );

  /* Format chunk data size. */
  data32 = endian_convert_u32( 0x10 );
  fwrite( &data32, sizeof(unsigned long), 1, w->fp );

  /* Format. */
  data16 = endian_convert_u16( w->format_type );
  fwrite( &data16, sizeof(unsigned short), 1, w->fp );

  /* Num channels. */
  data16 = endian_convert_u16( w->num_channels );
  fwrite( &data16, sizeof(unsigned short), 1, w->fp );

  /* Sample rate. */
  data32 = endian_convert_u32( w->sample_freq );
  fwrite( &data32, sizeof(unsigned long), 1, w->fp );
 
  /* Bytes per second.  PCM only. */
  data32 = endian_convert_u32( w->sample_freq * 
				  w->num_channels * 
				  w->bytes_per_sample );
  fwrite( &data32, sizeof(unsigned long), 1, w->fp );
  
  /* Block alignment. */
  data16 = endian_convert_u16( w->block_align );
  fwrite( &data16, sizeof(unsigned short), 1, w->fp );

  /* Sample size. */
  data16 = endian_convert_u16( w->bits_per_sample );
  fwrite( &data16, sizeof(unsigned short), 1, w->fp );

  /* Data chunk header. */
  fwrite( "data", sizeof(char), 4, w->fp );
  
  /* Data chunk data size. */
  data32 = endian_convert_u32( 0x00 );
  fwrite( &data32, sizeof(unsigned long), 1, w->fp );

  /* Ready to write data. */
  w->write_hdr_set = TRUE;
  w->data_start = ftell( w->fp );
  w->num_samples = 0;

  return WAV_OK;
}


/*****************************************************************************
 * wav_write_8()
 *
 * Write 8 bit data from buffers, with or without deinterlacing.
 * 
 *****************************************************************************/
void wav_write_8( FILE *fp, int num_ch, unsigned long num_s, 
		  bool deinter, unsigned char **src )
{
  unsigned long s;
  int ch;

  unsigned char *lsrc[WAV_MAX_CHANNELS];

  /* Copy pointers. */
  for( ch = 0; ch < num_ch; ++ch ) lsrc[ch] = src[ch];

  if( deinter && (num_ch > 1) )
    {
      /* Write each channel individually.  No endian convert
	 required for 8 bit data. */
      for( s = 0; s < num_s; ++s )
	for( ch = 0; ch < num_ch; ++ch )
	  {
	    fwrite( lsrc[ch], sizeof(unsigned char), 1, fp );
	    lsrc[ch]++;
	  }
    }
  else
    {
      /* Write everything with one call. */
      fwrite( lsrc[0], sizeof(unsigned char), num_s, fp );
    }
}


/*****************************************************************************
 * wav_write_16()
 *
 * Write 16 bit data from buffers, with or without deinterlacing and endian
 * conversion.
 * 
 *****************************************************************************/
void wav_write_16( FILE *fp, int num_ch, unsigned long num_s, 
		   bool deinter, bool endian, short int **src )
{
  unsigned long s;
  int ch;

  short int *lsrc[WAV_MAX_CHANNELS];

  /* Copy pointers. */
  for( ch = 0; ch < num_ch; ++ch ) lsrc[ch] = src[ch];

  if( endian || (deinter && (num_ch > 1)) )
    {
      /* Write each channel individually. */
      if( endian )
	{
	  /* With endian conversion. */
	  for( s = 0; s < num_s; ++s )
	    for( ch = 0; ch < num_ch; ++ch )
	      {
		*lsrc[ch] = endian_convert_u16( *lsrc[ch] );
		fwrite( lsrc[ch], sizeof(short int), 1, fp );
		lsrc[ch]++;
	      }
	}
      else
	{
	  /* Without endian conversion. */
	  for( s = 0; s < num_s; ++s )
	    for( ch = 0; ch < num_ch; ++ch )
	      {
		fwrite( lsrc[ch], sizeof(short int), 1, fp );
		lsrc[ch]++;
	      }
	}
    }
  else
    {
      /* Write everything with one call. */
      fwrite( lsrc[0], sizeof(short int), num_s, fp );
    }
}


/*****************************************************************************
 * wav_write_32()
 *
 * Write 32 bit data to buffers, with or without deinterlacing and endian
 * conversion.
 * 
 *****************************************************************************/
void wav_write_32( FILE *fp, int num_ch, unsigned long num_s, 
		   bool deinter, bool endian, unsigned long **src )
{
  unsigned long s;
  int ch;
  
  unsigned long *lsrc[WAV_MAX_CHANNELS];

  /* Copy pointers. */
  for( ch = 0; ch < num_ch; ++ch ) lsrc[ch] = src[ch];

  if( endian || (deinter && (num_ch > 1)) )
    {
      /* Read each channel individually. */
      if( endian )
	{
	  /* With endian conversion. */
	  for( s = 0; s < num_s; ++s )
	    for( ch = 0; ch < num_ch; ++ch )
	      {
		*lsrc[ch] = endian_convert_u32( *lsrc[ch] );
		fwrite( lsrc[ch], sizeof(unsigned long), 1, fp );
		lsrc[ch]++;
	      }
	}
      else
	{
	  /* Without endian conversion. */
	  for( s = 0; s < num_s; ++s )
	    for( ch = 0; ch < num_ch; ++ch )
	      {
		fwrite( lsrc[ch], sizeof(unsigned long), 1, fp );
		lsrc[ch]++;
	      }
	}
    }
  else
    {
      /* Write everything with one call. */
      fwrite( lsrc[0], sizeof(unsigned long), num_s, fp );
    }
}


/*****************************************************************************
 * wav_write()
 *
 * Write data to a WAV file.  The data is appended to the end of the
 * file.  Data may be interleaved or not.  Endian conversion may be
 * applied.  wav_write() may be called more than once to append data
 * to the file.
 *
 * Returns:  An error code.
 * Input:    w      - Wave structure.
 *           num_samples  - Number of samples to write.
 *           deinter      - TRUE if data is not interlaced, FALSE if it is.
 *           endian       - TRUE if endian conversion should be applied.
 *           src          - Array of destination buffer pointers.  Length of
 *                          array determined by wav_buffer_size().
 * Output:   
 *
 * On entry: wav_write_header() has been called once.
 *****************************************************************************/
wav_err_t wav_write( wav_t *w, unsigned long len,
		     bool deinter, bool endian, void **src )
{
  int num_ch;
  unsigned long num_s;
  wav_err_t err = WAV_OK;

  /* Check mode. */
  if( !w->mode_write || !w->write_hdr_set )
    return WAV_ERR_OPEN;

  /* Number of channels and samples per buffer. */
  num_ch = deinter ? w->num_channels : 1;
  num_s = len * (deinter ? 1 : w->num_channels);

  /* Seek to write position.  This use of block align only valid for PCM. */
  fseek( w->fp, 
	 w->data_start + (w->block_align * w->num_samples ), 
	 SEEK_SET );

  switch( w->bits_per_sample )
    {
    case 8:
      {
	wav_write_8( w->fp, num_ch, num_s, deinter, 
		     (unsigned char **)src );
	break;
      }
    case 16:
      {
	wav_write_16( w->fp, num_ch, num_s, deinter, endian, 
		      (short int **)src );
	break;
      }
    case 32:
      {
	wav_write_32( w->fp, num_ch, num_s, deinter, endian, 
		     (unsigned long **)src );
	break;
      }
    default:
      {
	err = WAV_ERR_WORD_LENGTH;
      }
    }

  /* Update number of samples written. */
  w->num_samples += len;

  return err;
  
}
